import ConnectDb from "../components/ConnectDb";

const Home = () => {
  return <ConnectDb />;
};

export default Home;
